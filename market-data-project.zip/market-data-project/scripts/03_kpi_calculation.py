"""
KPI Calculation and Analysis Module
Calculates vendor performance scores and statistical KPIs
"""

import pandas as pd
import numpy as np
from scipy import stats
import sqlite3
import os

def main():
    """
    Main KPI calculation function
    """
    print("📊 Calculating KPIs and vendor performance...")

    # Load processed data
    processed_data_path = 'data/processed_market_data.csv'
    if not os.path.exists(processed_data_path):
        print(f"❌ Processed data file not found: {processed_data_path}")
        return False

    df = pd.read_csv(processed_data_path)
    print(f"📊 Loaded {len(df)} processed records for KPI calculation")

    # Calculate vendor performance
    vendor_performance = calculate_vendor_performance(df)

    # Calculate overall KPIs
    kpi_summary = calculate_kpi_summary(df, vendor_performance)

    # Save to database
    save_to_database(vendor_performance, kpi_summary)

    print("✅ KPI calculation complete")
    return True

def calculate_vendor_performance(df):
    """
    Calculate performance metrics for each vendor
    """
    print("🏆 Calculating vendor performance scores...")

    vendor_metrics = []

    for vendor_id in df['Vendor_ID'].unique():
        vendor_data = df[df['Vendor_ID'] == vendor_id].copy()

        # Accuracy Score: Based on deviation from consensus price
        consensus_prices = df.groupby(['Security_ID', 'Price_Date'])['Price'].mean().reset_index()
        consensus_prices.columns = ['Security_ID', 'Price_Date', 'Consensus_Price']

        vendor_with_consensus = vendor_data.merge(consensus_prices, on=['Security_ID', 'Price_Date'], how='left')
        vendor_with_consensus['Price_Deviation'] = abs(vendor_with_consensus['Price'] - vendor_with_consensus['Consensus_Price'])
        accuracy_score = 1 - (vendor_with_consensus['Price_Deviation'] / vendor_with_consensus['Consensus_Price']).mean()

        # Consistency Score: Based on price stability (lower std dev is better)
        consistency_score = 1 / (1 + vendor_data.groupby('Security_ID')['Price'].std().mean())

        # Completeness Score: Based on data availability
        completeness_score = 1 - vendor_data['Price'].isna().mean()

        # Composite Score: Weighted average
        composite_score = (accuracy_score * 0.5 + consistency_score * 0.3 + completeness_score * 0.2)

        # Outlier analysis
        outlier_pct = (vendor_data['Outlier_Level'] != 'Normal').mean() * 100

        # Performance rating
        if composite_score >= 0.9:
            rating = 'Excellent'
        elif composite_score >= 0.8:
            rating = 'Good'
        elif composite_score >= 0.7:
            rating = 'Fair'
        else:
            rating = 'Poor'

        vendor_metrics.append({
            'Vendor_ID': vendor_id,
            'Vendor_Code': vendor_data['Vendor_Code'].iloc[0],
            'Accuracy_Score': round(accuracy_score, 4),
            'Consistency_Score': round(consistency_score, 4),
            'Completeness_Score': round(completeness_score, 4),
            'Composite_Score': round(composite_score, 4),
            'Performance_Rating': rating,
            'Total_Records': len(vendor_data),
            'Outlier_Percentage': round(outlier_pct, 2)
        })

    return pd.DataFrame(vendor_metrics)

def calculate_kpi_summary(df, vendor_performance):
    """
    Calculate overall KPI summary
    """
    print("📈 Calculating overall KPIs...")

    kpis = {
        'total_records': len(df),
        'unique_securities': df['Security_ID'].nunique(),
        'unique_vendors': df['Vendor_ID'].nunique(),
        'date_range_start': df['Price_Date'].min(),
        'date_range_end': df['Price_Date'].max(),
        'avg_price': df['Price'].mean(),
        'price_std': df['Price'].std(),
        'missing_values_pct': df['Price'].isna().mean() * 100,
        'normal_records': (df['Outlier_Level'] == 'Normal').sum(),
        'moderate_outliers': (df['Outlier_Level'] == 'Moderate').sum(),
        'severe_outliers': (df['Outlier_Level'] == 'Severe').sum(),
        'extreme_outliers': (df['Outlier_Level'] == 'Extreme').sum(),
        'outlier_total': (df['Outlier_Level'] != 'Normal').sum(),
        'outlier_percentage': ((df['Outlier_Level'] != 'Normal').sum() / len(df)) * 100,
        'best_vendor': vendor_performance.loc[vendor_performance['Composite_Score'].idxmax(), 'Vendor_Code'],
        'worst_vendor': vendor_performance.loc[vendor_performance['Composite_Score'].idxmin(), 'Vendor_Code'],
        'avg_vendor_score': vendor_performance['Composite_Score'].mean()
    }

    # Convert to DataFrame for database storage
    kpi_df = pd.DataFrame(list(kpis.items()), columns=['KPI_Name', 'Value'])

    return kpi_df

def save_to_database(vendor_performance, kpi_summary):
    """
    Save KPI results to database
    """
    print("💾 Saving KPI results to database...")

    conn = sqlite3.connect('data/market_analytics.db')

    # Save vendor performance
    vendor_performance.to_sql('vendor_performance', conn, if_exists='replace', index=False)

    # Save KPI summary
    kpi_summary.to_sql('kpi_summary', conn, if_exists='replace', index=False)

    # Create indexes
    conn.execute('CREATE INDEX IF NOT EXISTS idx_vendor_perf ON vendor_performance (Vendor_ID)')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_kpi ON kpi_summary (KPI_Name)')

    conn.close()
    print("✅ KPI results saved to database")

    return True

if __name__ == "__main__":
    main()
