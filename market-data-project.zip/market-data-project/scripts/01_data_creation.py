"""
Advanced Market Data Generator
Creates realistic financial market data with anomalies
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
from scipy import stats

def create_advanced_dataset():
    """
    Create realistic market data with:
    - 5 vendors with different data quality
    - Anomalies and outliers
    - Seasonal patterns
    - Missing values
    - Currency variations
    """
    
    np.random.seed(42)
    
    # Configuration
    NUM_DAYS = 90  # 3 months of data
    SECURITIES = [
        'US0378331005',  # Apple
        'US5949181045',  # Microsoft
        'US0231351067',  # Amazon
        'US4781601046',  # JPMorgan
        'US02079K3059',  # Alphabet
        'US30303M1027',  # Meta
        'US88160R1014',  # Tesla
        'US38141G1040',  # NVIDIA
        'US0846707026',  # Berkshire
        'US9026531049'   # Visa
    ]
    
    VENDORS = [
        {'id': 'V001', 'code': 'BLOOM', 'reliability': 0.95, 'bias': 0.01},
        {'id': 'V002', 'code': 'REUTER', 'reliability': 0.90, 'bias': -0.005},
        {'id': 'V003', 'code': 'REFIG', 'reliability': 0.85, 'bias': 0.02},
        {'id': 'V004', 'code': 'MARKIT', 'reliability': 0.92, 'bias': -0.01},
        {'id': 'V005', 'code': 'ICE', 'reliability': 0.88, 'bias': 0.015}
    ]
    
    PRICE_TYPES = ['Close', 'Bid', 'Ask', 'Open', 'Mid', 'NAV']
    EXCHANGES = ['NYSE', 'NASDAQ', 'LSE', 'TSE', 'HKEX', 'EURONEXT']
    CURRENCIES = ['USD', 'EUR', 'GBP', 'JPY', 'CAD']
    
    data = []
    start_date = datetime(2024, 1, 1)
    
    # Base prices for each security
    base_prices = {
        'US0378331005': 180.0,  # AAPL
        'US5949181045': 340.0,  # MSFT
        'US0231351067': 150.0,  # AMZN
        'US4781601046': 170.0,  # JPM
        'US02079K3059': 140.0,  # GOOGL
        'US30303M1027': 480.0,  # META
        'US88160R1014': 240.0,  # TSLA
        'US38141G1040': 500.0,  # NVDA
        'US0846707026': 360.0,  # BRK-B
        'US9026531049': 280.0   # V
    }
    
    # Generate data
    for day in range(NUM_DAYS):
        current_date = start_date + timedelta(days=day)
        
        # Market trend (bullish/bearish day)
        market_trend = np.random.normal(1.0, 0.02)
        day_of_week = current_date.weekday()
        
        # Weekend effect
        if day_of_week >= 5:  # Weekend
            continue
        
        for security in SECURITIES:
            base_price = base_prices[security]
            
            # Simulate real price movement (random walk with drift)
            volatility = 0.02  # 2% daily volatility
            daily_return = np.random.normal(0.0005, volatility)
            base_price *= (1 + daily_return)
            
            for vendor_info in VENDORS:
                vendor_id = vendor_info['id']
                vendor_code = vendor_info['code']
                reliability = vendor_info['reliability']
                bias = vendor_info['bias']
                
                # Generate source feed (multiple feeds per vendor)
                num_feeds = random.randint(1, 3)
                for feed_num in range(num_feeds):
                    source_feed = f"{vendor_code}_FEED_{feed_num+1:02d}"
                    
                    for price_type in PRICE_TYPES[:random.randint(1, 3)]:  # Random subset
                        exchange = random.choice(EXCHANGES)
                        currency = random.choice(CURRENCIES)
                        
                        # Calculate vendor-specific price with bias and noise
                        vendor_price = base_price * (1 + bias)
                        
                        # Add vendor-specific noise based on reliability
                        noise = np.random.normal(0, 0.01 * (1 - reliability))
                        vendor_price *= (1 + noise)
                        
                        # Add price type adjustment
                        if price_type == 'Bid':
                            vendor_price *= 0.9995
                        elif price_type == 'Ask':
                            vendor_price *= 1.0005
                        elif price_type == 'Mid':
                            vendor_price = (vendor_price * 0.9995 + vendor_price * 1.0005) / 2
                        
                        # Currency conversion rates (simplified)
                        currency_rates = {
                            'USD': 1.0,
                            'EUR': 0.92,
                            'GBP': 0.79,
                            'JPY': 148.0,
                            'CAD': 1.35
                        }
                        
                        # Convert to selected currency
                        if currency != 'USD':
                            vendor_price *= currency_rates[currency]
                        
                        # Round to appropriate decimals
                        vendor_price = round(vendor_price, 4)
                        
                        # Introduce missing values (5% chance)
                        if np.random.random() > 0.95:
                            vendor_price = np.nan
                        
                        # Introduce outliers (2% chance)
                        if np.random.random() > 0.98:
                            outlier_factor = np.random.choice([0.9, 1.1, 0.5, 1.5])
                            vendor_price *= outlier_factor
                        
                        # Create record
                        record = {
                            'Security_ID': security,
                            'Vendor_ID': vendor_id,
                            'Vendor_Code': vendor_code,
                            'Source_Feed_ID': source_feed,
                            'Price_Type': price_type,
                            'Exchange_Code': exchange,
                            'Price_Date': current_date.strftime('%Y-%m-%d'),
                            'Currency_Code': currency,
                            'Price': vendor_price,
                            'Currency_Rate': currency_rates[currency],
                            'Day_of_Week': day_of_week,
                            'Month': current_date.month,
                            'Quarter': (current_date.month - 1) // 3 + 1
                        }
                        
                        data.append(record)
    
    # Create DataFrame
    df = pd.DataFrame(data)
    
    # Add some additional features
    df['Security_Type'] = np.where(df['Security_ID'].str.contains('US'), 'Equity', 'Bond')
    df['Region'] = np.where(df['Exchange_Code'].isin(['NYSE', 'NASDAQ']), 'North America',
                           np.where(df['Exchange_Code'].isin(['LSE', 'EURONEXT']), 'Europe', 'Asia'))
    
    # Save to CSV
    df.to_csv('data/raw_market_data.csv', index=False)
    print(f"✅ Dataset created with {len(df)} rows")
    print(f"📊 Columns: {df.columns.tolist()}")
    
    # Generate summary statistics
    print("\n📈 Dataset Summary:")
    print(f"Unique Securities: {df['Security_ID'].nunique()}")
    print(f"Unique Vendors: {df['Vendor_ID'].nunique()}")
    print(f"Date Range: {df['Price_Date'].min()} to {df['Price_Date'].max()}")
    print(f"Missing Values: {df['Price'].isna().sum()} ({df['Price'].isna().mean()*100:.1f}%)")
    
    return df

if __name__ == "__main__":
    df = create_advanced_dataset()
    print("\n🎯 First 5 rows of data:")
    print(df.head())
