"""
Dashboard Data Preparation Module
Prepares optimized CSV files for Power BI dashboard
"""

import pandas as pd
import sqlite3
import os
import json

def main():
    """
    Main dashboard data preparation function
    """
    print("📊 Preparing dashboard data...")

    # Load data from database
    db_path = 'data/market_analytics.db'
    if not os.path.exists(db_path):
        print(f"❌ Database not found: {db_path}")
        return False

    conn = sqlite3.connect(db_path)

    # Load main data
    df = pd.read_sql('SELECT * FROM market_data', conn)
    vendor_performance = pd.read_sql('SELECT * FROM vendor_performance', conn)
    kpi_summary = pd.read_sql('SELECT * FROM kpi_summary', conn)

    conn.close()

    print(f"📊 Loaded {len(df)} records for dashboard preparation")

    # Create dashboard data folder
    os.makedirs('dashboard/powerbi_data', exist_ok=True)

    # Prepare and save CSV files
    prepare_vendor_performance(vendor_performance)
    prepare_price_deviation(df)
    prepare_time_series(df)
    prepare_outlier_heatmap(df)
    prepare_kpi_summary(kpi_summary)
    prepare_security_summary(df)
    prepare_calendar(df)

    # Create relationships file
    create_relationships_file()

    # Create template
    create_powerbi_template()

    print("✅ Dashboard data preparation complete")
    return True

def prepare_vendor_performance(vendor_df):
    """Prepare vendor performance data"""
    print("🏆 Preparing vendor performance data...")

    # Select and rename columns for dashboard
    dashboard_cols = {
        'Vendor_Code': 'Vendor',
        'Composite_Score': 'Performance_Score',
        'Accuracy_Score': 'Accuracy',
        'Consistency_Score': 'Consistency',
        'Completeness_Score': 'Completeness',
        'Performance_Rating': 'Rating',
        'Total_Records': 'Record_Count',
        'Outlier_Percentage': 'Outlier_Pct'
    }

    vendor_dashboard = vendor_df[list(dashboard_cols.keys())].rename(columns=dashboard_cols)
    vendor_dashboard.to_csv('dashboard/powerbi_data/vendor_performance.csv', index=False)

def prepare_price_deviation(df):
    """Prepare price deviation analysis"""
    print("📈 Preparing price deviation data...")

    # Group by security and vendor
    deviation_data = df.groupby(['Security_ID', 'Vendor_Code']).agg({
        'Price': ['count', 'mean', 'std'],
        'Z_Score': 'mean',
        'Outlier_Level': lambda x: (x != 'Normal').sum()
    }).reset_index()

    # Flatten column names
    deviation_data.columns = ['Security_ID', 'Vendor_Code', 'Record_Count', 'Avg_Price', 'Price_Std', 'Avg_Z_Score', 'Outlier_Count']

    # Calculate deviation percentage
    deviation_data['Deviation_Pct'] = (deviation_data['Price_Std'] / deviation_data['Avg_Price']) * 100

    deviation_data.to_csv('dashboard/powerbi_data/price_deviation.csv', index=False)

def prepare_time_series(df):
    """Prepare time series data"""
    print("📅 Preparing time series data...")

    # Convert date and group by date
    df['Price_Date'] = pd.to_datetime(df['Price_Date'])
    df['Month_Year'] = df['Price_Date'].dt.strftime('%Y-%m')

    time_series = df.groupby(['Price_Date', 'Security_ID']).agg({
        'Price': ['mean', 'min', 'max', 'std', 'count']
    }).reset_index()

    # Flatten columns
    time_series.columns = ['Date', 'Security_ID', 'Avg_Price', 'Min_Price', 'Max_Price', 'Price_Std', 'Record_Count']

    # Calculate moving averages
    time_series = time_series.sort_values(['Security_ID', 'Date'])
    time_series['MA_7'] = time_series.groupby('Security_ID')['Avg_Price'].transform(lambda x: x.rolling(7, min_periods=1).mean())
    time_series['MA_30'] = time_series.groupby('Security_ID')['Avg_Price'].transform(lambda x: x.rolling(30, min_periods=1).mean())

    time_series.to_csv('dashboard/powerbi_data/time_series.csv', index=False)

def prepare_outlier_heatmap(df):
    """Prepare outlier heatmap data"""
    print("🔥 Preparing outlier heatmap data...")

    # Group by security and date for heatmap
    heatmap_data = df.groupby(['Security_ID', 'Price_Date', 'Outlier_Level']).size().reset_index(name='Count')

    # Pivot to get outlier levels as columns
    heatmap_pivot = heatmap_data.pivot_table(
        index=['Security_ID', 'Price_Date'],
        columns='Outlier_Level',
        values='Count',
        fill_value=0
    ).reset_index()

    # Ensure all outlier levels exist
    for level in ['Normal', 'Moderate', 'Severe', 'Extreme']:
        if level not in heatmap_pivot.columns:
            heatmap_pivot[level] = 0

    heatmap_pivot.to_csv('dashboard/powerbi_data/outlier_heatmap.csv', index=False)

def prepare_kpi_summary(kpi_df):
    """Prepare KPI summary for dashboard cards"""
    print("📋 Preparing KPI summary...")

    # Convert values to proper types and create dict
    kpi_cards = {}
    for _, row in kpi_df.iterrows():
        kpi_name = row['KPI_Name']
        value = row['Value']

        # Handle different data types from SQLite
        if isinstance(value, (int, float)):
            kpi_cards[kpi_name] = value
        elif isinstance(value, str):
            try:
                kpi_cards[kpi_name] = float(value)
            except ValueError:
                kpi_cards[kpi_name] = 0
        else:
            # Handle bytes or other types
            try:
                kpi_cards[kpi_name] = float(str(value))
            except (ValueError, TypeError):
                kpi_cards[kpi_name] = 0

    # Create dashboard-friendly format
    kpi_dashboard = pd.DataFrame([
        {'Metric': 'Total Records', 'Value': int(kpi_cards.get('total_records', 0)), 'Category': 'Volume'},
        {'Metric': 'Unique Securities', 'Value': int(kpi_cards.get('unique_securities', 0)), 'Category': 'Coverage'},
        {'Metric': 'Unique Vendors', 'Value': int(kpi_cards.get('unique_vendors', 0)), 'Category': 'Coverage'},
        {'Metric': 'Average Price', 'Value': round(float(kpi_cards.get('avg_price', 0)), 2), 'Category': 'Statistics'},
        {'Metric': 'Price Volatility', 'Value': round(float(kpi_cards.get('price_std', 0)), 2), 'Category': 'Statistics'},
        {'Metric': 'Outlier Records', 'Value': int(kpi_cards.get('moderate_outliers', 0)) + int(kpi_cards.get('severe_outliers', 0)) + int(kpi_cards.get('extreme_outliers', 0)), 'Category': 'Quality'}
    ])

    kpi_dashboard.to_csv('dashboard/powerbi_data/kpi_summary.csv', index=False)

def prepare_security_summary(df):
    """Prepare security-level summary"""
    print("🏢 Preparing security summary...")

    security_summary = df.groupby('Security_ID').agg({
        'Price': ['count', 'mean', 'std', 'min', 'max'],
        'Vendor_ID': 'nunique',
        'Outlier_Level': lambda x: (x != 'Normal').sum(),
        'Z_Score': 'std'
    }).reset_index()

    # Flatten columns
    security_summary.columns = ['Security_ID', 'Record_Count', 'Avg_Price', 'Price_Std', 'Min_Price', 'Max_Price', 'Vendor_Count', 'Outlier_Count', 'Z_Score_Std']

    # Calculate risk rating
    security_summary['Risk_Rating'] = pd.cut(
        security_summary['Outlier_Count'] / security_summary['Record_Count'],
        bins=[0, 0.05, 0.1, 0.2, 1],
        labels=['Low', 'Medium', 'High', 'Very High']
    )

    security_summary.to_csv('dashboard/powerbi_data/security_summary.csv', index=False)

def prepare_calendar(df):
    """Prepare calendar dimension table"""
    print("📆 Preparing calendar data...")

    # Get unique dates
    dates = pd.to_datetime(df['Price_Date'].unique())
    calendar = pd.DataFrame({'Date': dates})

    # Add calendar attributes
    calendar['Year'] = calendar['Date'].dt.year
    calendar['Month'] = calendar['Date'].dt.month
    calendar['Month_Name'] = calendar['Date'].dt.strftime('%B')
    calendar['Quarter'] = calendar['Date'].dt.quarter
    calendar['Day_of_Week'] = calendar['Date'].dt.day_name()
    calendar['Week_Number'] = calendar['Date'].dt.isocalendar().week

    calendar.to_csv('dashboard/powerbi_data/calendar.csv', index=False)

def create_relationships_file():
    """Create JSON file with Power BI relationships"""
    print("🔗 Creating relationships file...")

    relationships = {
        "relationships": [
            {
                "from_table": "time_series",
                "from_column": "Date",
                "to_table": "calendar",
                "to_column": "Date"
            },
            {
                "from_table": "price_deviation",
                "from_column": "Security_ID",
                "to_table": "security_summary",
                "to_column": "Security_ID"
            }
        ]
    }

    with open('dashboard/powerbi_data/relationships.json', 'w') as f:
        json.dump(relationships, f, indent=2)

def create_powerbi_template():
    """Create Power BI template guide"""
    print("📝 Creating Power BI template...")

    template = """
# Market Data Analytics - Power BI Dashboard Template

## Dashboard Pages Structure

### 1. Executive Summary
- KPI Cards: Total Records, Unique Securities, Average Price, Outlier Percentage
- Vendor Performance Overview Chart
- Risk Distribution by Security

### 2. Vendor Performance Analysis
- Vendor Performance Scores (Bar Chart)
- Vendor Accuracy vs Consistency (Scatter Plot)
- Outlier Distribution by Vendor (Heatmap)

### 3. Price Deviation Analysis
- Price Deviation by Security and Vendor (Matrix)
- Z-Score Distribution (Histogram)
- Outlier Trends Over Time (Line Chart)

### 4. Time Series Analysis
- Price Trends with Moving Averages (Line Chart)
- Volatility Analysis (Area Chart)
- Price Range Visualization (Candlestick-style)

### 5. Outlier Investigation
- Outlier Heatmap by Security and Date
- Outlier Severity Distribution (Pie Chart)
- Detailed Outlier Records (Table)

### 6. Security Risk Assessment
- Risk Rating Distribution (Treemap)
- Security Performance Comparison (Bar Chart)
- Vendor Coverage by Security (Matrix)

## Key DAX Measures

### Performance Metrics
```
Vendor Performance Score = AVERAGE('vendor_performance'[Performance_Score])
Accuracy Rate = AVERAGE('vendor_performance'[Accuracy])
Outlier Percentage = SUM('market_data'[Outlier_Count]) / SUM('market_data'[Record_Count])
```

### Statistical Measures
```
Price Volatility = STDEV.P('time_series'[Avg_Price])
Average Deviation = AVERAGE('price_deviation'[Deviation_Pct])
Z-Score Magnitude = ABS(AVERAGE('market_data'[Z_Score]))
```

### Time Intelligence
```
Previous Month Price = CALCULATE(AVERAGE('time_series'[Avg_Price]), DATEADD('calendar'[Date], -1, MONTH))
Price Change % = DIVIDE(([Average Price] - [Previous Month Price]), [Previous Month Price])
```

## Visual Recommendations

1. **Use consistent color scheme**: Green for good performance, Red for poor performance, Yellow for warnings
2. **Implement drill-through**: Allow users to drill from summary to detailed views
3. **Add slicers**: Date range, Security selection, Vendor selection
4. **Use conditional formatting**: Highlight outliers and poor performance
5. **Add tooltips**: Show detailed metrics on hover

## Data Refresh Setup

1. Schedule daily refresh to update with new market data
2. Set up incremental refresh for large datasets
3. Configure alerts for data quality issues

---
Template generated for Market Data Analytics Dashboard
"""

    with open('dashboard/powerbi_template.txt', 'w', encoding='utf-8') as f:
        f.write(template)

if __name__ == "__main__":
    main()
