"""
Data Preprocessing and Cleaning Module
Handles data cleaning, outlier detection, and data preparation
"""

import pandas as pd
import numpy as np
from scipy import stats
import sqlite3
import os

def main():
    """
    Main preprocessing function
    """
    print("🔄 Starting data preprocessing...")

    # Load raw data
    raw_data_path = 'data/raw_market_data.csv'
    if not os.path.exists(raw_data_path):
        print(f"❌ Raw data file not found: {raw_data_path}")
        return False

    df = pd.read_csv(raw_data_path)
    print(f"📊 Loaded {len(df)} raw records")

    # Data cleaning
    df_clean = clean_data(df)

    # Outlier detection
    df_clean = detect_outliers(df_clean)

    # Save processed data
    df_clean.to_csv('data/processed_market_data.csv', index=False)
    print(f"✅ Processed data saved: {len(df_clean)} records")

    # Create database
    create_database(df_clean)

    return True

def clean_data(df):
    """
    Clean and preprocess the data
    """
    print("🧹 Cleaning data...")

    # Remove duplicates
    df = df.drop_duplicates()
    print(f"Removed duplicates: {len(df)} records remaining")

    # Handle missing values
    df['Price'] = df['Price'].fillna(df.groupby(['Security_ID', 'Price_Date'])['Price'].transform('mean'))
    df['Price'] = df['Price'].fillna(df.groupby('Security_ID')['Price'].transform('mean'))
    print(f"Handled missing values: {df['Price'].isna().sum()} remaining")

    # Convert data types
    df['Price_Date'] = pd.to_datetime(df['Price_Date'])
    df['Price'] = pd.to_numeric(df['Price'], errors='coerce')

    # Filter out invalid prices
    df = df[df['Price'] > 0]

    return df

def detect_outliers(df):
    """
    Detect and categorize outliers
    """
    print("🔍 Detecting outliers...")

    # Calculate rolling statistics for each security
    df = df.sort_values(['Security_ID', 'Price_Date'])

    # Rolling mean and std
    df['Rolling_Mean'] = df.groupby('Security_ID')['Price'].transform(lambda x: x.rolling(window=5, min_periods=1).mean())
    df['Rolling_Std'] = df.groupby('Security_ID')['Price'].transform(lambda x: x.rolling(window=5, min_periods=1).std())

    # Z-score calculation
    df['Z_Score'] = (df['Price'] - df['Rolling_Mean']) / df['Rolling_Std']

    # Outlier categorization
    df['Outlier_Level'] = 'Normal'
    df.loc[df['Z_Score'].abs() > 2, 'Outlier_Level'] = 'Moderate'
    df.loc[df['Z_Score'].abs() > 3, 'Outlier_Level'] = 'Severe'
    df.loc[df['Z_Score'].abs() > 5, 'Outlier_Level'] = 'Extreme'

    print(f"Outlier detection complete: {len(df[df['Outlier_Level'] != 'Normal'])} outliers found")

    return df

def create_database(df):
    """
    Create SQLite database with processed data
    """
    print("💾 Creating database...")

    conn = sqlite3.connect('data/market_analytics.db')

    # Save main data table
    df.to_sql('market_data', conn, if_exists='replace', index=False)

    # Create indexes for better performance
    conn.execute('CREATE INDEX IF NOT EXISTS idx_security_date ON market_data (Security_ID, Price_Date)')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_vendor ON market_data (Vendor_ID)')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_outlier ON market_data (Outlier_Level)')

    conn.close()
    print("✅ Database created successfully")

    return True

if __name__ == "__main__":
    main()
