# Market Data Analytics - Price Challenge Reporting

## Project Overview
This project implements a comprehensive market data analytics solution for comparing vendor pricing data and generating price challenge reports.

## Project Structure
market-data-project/
├── data/ # Raw and processed data files
├── scripts/ # Python scripts for data processing
├── dashboard/ # Power BI dashboard files
├── reports/ # Project reports and documentation
└── logs/ # Execution logs

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run complete pipeline: `python run_project.py`
3. Open dashboard: Load Power BI files from dashboard/

## Key Features
- Data preprocessing and cleaning
- Statistical KPI calculation
- Vendor performance scoring
- Interactive Power BI dashboard
- Automated reporting

## Technologies Used
- Python (Pandas, NumPy, SciPy)
- SQLite for data storage
- Power BI for visualization
- Excel for reporting
