# TODO List for Market Data Project File Creation

- [x] Create requirements.txt with common Python libraries for data analysis
- [x] Create README.md with project description
- [x] Create data/raw_data.csv with sample CSV headers for raw market data
- [x] Create data/processed_data.csv with sample processed data CSV
- [x] Create data/reporting_tables.csv with sample reporting tables CSV
- [x] Create scripts/01_data_creation.py with basic script to create sample data
- [x] Create scripts/02_data_preprocessing.py with script for preprocessing
- [x] Create scripts/03_kpi_calculation.py with script for KPI calculations
- [x] Create scripts/04_dashboard_data.py with script for dashboard data preparation
- [x] Create dashboard/price_challenge_report.pbix as empty file (Power BI report)
- [x] Create dashboard/dashboard_screenshot.png as empty file (image)
- [x] Create project_report.docx as empty file (document)
